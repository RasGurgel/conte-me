import { Link } from "@tanstack/react-router";

export function EmptyLibrary() {
  return (
    <div className="mx-auto flex max-w-sm flex-col items-center gap-4 px-6 py-20 text-center">
      <div className="text-6xl">🌙</div>
      <h2 className="font-display text-2xl font-semibold text-foreground">
        A biblioteca está vazia
      </h2>
      <p className="text-sm text-muted-foreground">
        Vá ao painel Admin e adicione a primeira historinha!
      </p>
      <Link
        to="/admin"
        className="mt-2 rounded-full bg-amber px-5 py-2 text-sm font-medium text-primary-foreground shadow-sm transition hover:opacity-90"
      >
        Abrir painel Admin
      </Link>
    </div>
  );
}
