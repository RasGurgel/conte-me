import { Link } from "@tanstack/react-router";
import { BookOpenText, PencilLine } from "lucide-react";

export function BottomNav({ active }: { active: "library" | "admin" }) {
  const base =
    "flex flex-1 flex-col items-center justify-center gap-1 py-2 text-xs font-medium tracking-wide transition-colors";
  const on = "text-foreground";
  const off = "text-muted-foreground";
  return (
    <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-border/60 bg-background/85 backdrop-blur safe-bottom">
      <div className="mx-auto flex max-w-md">
        <Link to="/" className={`${base} ${active === "library" ? on : off}`}>
          <BookOpenText className="h-5 w-5" />
          Biblioteca
        </Link>
        <Link to="/admin" className={`${base} ${active === "admin" ? on : off}`}>
          <PencilLine className="h-5 w-5" />
          Admin
        </Link>
      </div>
    </nav>
  );
}
