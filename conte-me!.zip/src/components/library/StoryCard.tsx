import { Lock } from "lucide-react";
import type { Story } from "@/types/story";

type Props = {
  story: Story;
  state: "past" | "today" | "future";
  onOpen: () => void;
};

export function StoryCard({ story, state, onOpen }: Props) {
  const locked = state === "future";
  return (
    <button
      type="button"
      onClick={onOpen}
      className={`press-active relative flex w-full items-stretch gap-3 overflow-hidden rounded-[20px] border bg-card text-left shadow-[0_2px_10px_-4px_rgba(60,40,10,0.12)] transition ${
        state === "today"
          ? "border-amber"
          : "border-border/70"
      } ${locked ? "opacity-55 [filter:grayscale(0.4)] cursor-default" : ""}`}
      aria-disabled={locked}
    >
      <div className="relative h-[100px] w-[100px] shrink-0 overflow-hidden bg-secondary">
        {story.cover_url ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={story.cover_url}
            alt=""
            className="h-full w-full object-cover"
            loading="lazy"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-4xl">
            {story.emoji || "📖"}
          </div>
        )}
      </div>
      <div className="flex min-w-0 flex-1 flex-col justify-center gap-1 py-2 pr-3">
        {state === "today" && (
          <span className="w-fit rounded-full bg-amber px-2 py-[2px] text-[10px] font-semibold uppercase tracking-wider text-primary-foreground">
            hoje
          </span>
        )}
        <h3 className="font-display truncate text-lg font-semibold leading-tight text-foreground">
          {story.title}
        </h3>
        {story.subtitle && (
          <p className="truncate text-xs italic text-muted-foreground">{story.subtitle}</p>
        )}
        <div className="mt-1 flex items-center gap-1.5">
          {story.tags?.slice(0, 3).map((t) => (
            <span
              key={t}
              className="rounded-full bg-muted px-2 py-[2px] text-[10px] text-muted-foreground"
            >
              {t}
            </span>
          ))}
          {locked && (
            <span className="ml-auto inline-flex items-center gap-1 text-[11px] text-muted-foreground">
              <Lock className="h-3 w-3" />
            </span>
          )}
        </div>
      </div>
    </button>
  );
}
