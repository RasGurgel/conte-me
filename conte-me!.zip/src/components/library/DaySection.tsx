import type { ReactNode } from "react";

export function DaySection({
  label,
  isToday,
  children,
}: {
  label: string;
  isToday: boolean;
  children: ReactNode;
}) {
  return (
    <section className="space-y-3">
      <h2 className="font-display text-sm font-medium tracking-wide text-muted-foreground">
        {label}
        {isToday && <span className="ml-2 text-amber">— hoje</span>}
      </h2>
      <div className="space-y-3">{children}</div>
    </section>
  );
}
