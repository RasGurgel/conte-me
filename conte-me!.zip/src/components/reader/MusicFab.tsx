import { Music } from "lucide-react";

export function MusicFab({ enabled, onClick }: { enabled: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label="Música de fundo"
      className={`relative flex h-10 w-10 items-center justify-center rounded-full backdrop-blur transition ${
        enabled
          ? "bg-foreground/90 text-background"
          : "bg-foreground/15 text-foreground/70 opacity-70"
      }`}
    >
      <Music className="h-4 w-4" />
      {!enabled && (
        <span className="pointer-events-none absolute h-[2px] w-6 rotate-45 rounded bg-foreground/70" />
      )}
    </button>
  );
}
