import { Volume2, VolumeX } from "lucide-react";

type Props = {
  enabled: boolean;
  playing: boolean;
  disabled: boolean;
  onClick: () => void;
};

export function NarrationFab({ enabled, playing, disabled, onClick }: Props) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      aria-label="Narração"
      className={`flex h-10 w-10 items-center justify-center rounded-full backdrop-blur transition ${
        enabled
          ? "bg-foreground/90 text-background"
          : "bg-foreground/15 text-foreground/70 opacity-70"
      } ${playing ? "animate-pulse-narration" : ""} disabled:opacity-30`}
    >
      {enabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
    </button>
  );
}
