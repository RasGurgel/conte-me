import { useEffect, useState } from "react";

export function ProgressDots({ current, total }: { current: number; total: number }) {
  const [showLabel, setShowLabel] = useState(true);
  useEffect(() => {
    setShowLabel(true);
    const t = window.setTimeout(() => setShowLabel(false), 3000);
    return () => clearTimeout(t);
  }, [current]);

  if (total <= 1) return null;

  return (
    <div className="pointer-events-none absolute inset-x-0 bottom-3 z-20 flex flex-col items-center gap-1.5">
      {total <= 14 ? (
        <div className="flex items-center gap-1.5">
          {Array.from({ length: total }).map((_, i) => (
            <span
              key={i}
              className={`h-1.5 w-1.5 rounded-full transition-all ${
                i === current
                  ? "scale-125 bg-foreground/55"
                  : "bg-foreground/20"
              }`}
            />
          ))}
        </div>
      ) : (
        <div className="relative h-[3px] w-[40%] overflow-hidden rounded-full bg-foreground/15">
          <span
            className="absolute inset-y-0 left-0 bg-foreground/60 transition-[width]"
            style={{ width: `${((current + 1) / total) * 100}%` }}
          />
        </div>
      )}
      <span
        className={`text-[10px] font-medium uppercase tracking-widest text-foreground/55 transition-opacity duration-500 ${
          showLabel ? "opacity-100" : "opacity-0"
        }`}
      >
        {current + 1} / {total}
      </span>
    </div>
  );
}
